/**
 * Clasa ce reprezinta o solutie partiala pentru problema de rezolvat. Aceste
 * solutii partiale constituie task-uri care sunt introduse in workpool.
 */

public abstract class PartialSolution {
	
	public PartialSolution(){
	}
	
	public String toString() {
		return null;
	}
}
